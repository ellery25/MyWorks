x  = 1

while x+1 > 1:
    x /= 2

x = 2*x

print(x)