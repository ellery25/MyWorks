
package FlyWeightComposition;

/**
 *
 * @author HOME
 */
public interface FlyWeight {
    
    void operacionCompartida();
    
}
